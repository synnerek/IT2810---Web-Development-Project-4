export type RootStackParamList = {
    HomePage: undefined
    DisplayMovie: {id: number}
    Login: undefined
    CreateUser: undefined
    LikedMovies: undefined
}
